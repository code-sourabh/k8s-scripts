from kubernetes import client
from decouple import config

configuration = client.Configuration()
configuration.api_key["authorization"] = config('POD')

print(config('POD'))

configuration.api_key_prefix['authorization'] = 'Bearer'
# configuration.host = "kubernetes.default.svc"
configuration.host = 'https://34.100.175.181'
# configuration.username = "user1"
# verify_ssl = False
configuration.ssl_ca_cert = 'ca.crt'

api_instance = client.AppsV1Api(client.ApiClient(configuration))

NAMESPACE = "default"
DEPLOYMENT_NAME = "nginx"
SCALE = 2

deployment = api_instance.read_namespaced_deployment(name=DEPLOYMENT_NAME, namespace=NAMESPACE)
deployment.spec.replicas = 2
api_instance.replace_namespaced_deployment(name=DEPLOYMENT_NAME, namespace=NAMESPACE, body=deployment)

print(deployment.spec.replicas)